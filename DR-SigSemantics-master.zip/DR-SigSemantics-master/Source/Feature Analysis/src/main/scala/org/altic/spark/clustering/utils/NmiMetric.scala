package org.altic.spark.clustering.utils

/**
 * Created with IntelliJ IDEA.
 * User: tug
 * Date: 24/05/13
 * Time: 19:02
 * To change this template use File | Settings | File Templates.
 */
//object NmiMetric extends App {
object NmiMetric {
  def jointProbabilty(x: Array[Int], y: Array[Int]) {

  }
}
