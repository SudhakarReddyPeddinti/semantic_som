package org.altic.spark.clustering

/**
  * Created by Rakesh on 6/20/2016.
  */


import java.io.File

import org.altic.spark.clustering.NLPUtils._
import org.altic.spark.clustering.Utils._
import org.altic.spark.clustering.utils.{SparkReader, IO}
import org.apache.spark.mllib.clustering.KMeans
import org.apache.spark.mllib.feature.{HashingTF, IDF}
import org.apache.spark.mllib.linalg.{Vectors, Vector}
import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkConf, SparkContext}

import scala.reflect.io.Path


object SparkTFIDF {
  val labelToNumeric = createLabelMap("docs/inputData")
  class Experience(val datasetDir: String, val outputDir: String, val name: String, val nbProtoRow: Int, val nbProtoCol: Int, val ext: String = ".data") {
    def dir: String = datasetDir + "/" + name

    def outDir: String = outputDir + "/" + name

    def dataPath: String = if (ext.length > 1) dir + "/" + name + ext else dir

    def nbTotProto: Int = nbProtoCol * nbProtoRow
  }
  def cleanResults(exp: Experience) {
    val resultDirs = new File(exp.dir).listFiles.filter(_.getName.startsWith(exp.name + ".clustering"))
    resultDirs.foreach(IO.delete)
    println("Removed " + exp.dir)
  }

  def getListOfSubDirectories(directoryName: String): Array[String] = {
    new File(directoryName).listFiles.filter(_.isDirectory).map(_.getName)
  }

  def main(args: Array[String]) {
    System.setProperty("hadoop.home.dir","F:\\winutils")

    val conf = new SparkConf().setAppName("SparkTFIDF").setMaster("local[*]").set("spark.executor.memory", "4g")
    val sc = new SparkContext(conf)
    //paths
    val filepath = "docs/inputData"
    val outfilepath = "docs/outputData"

    //code to inserted here to file dir
    val dirs = getListOfSubDirectories(filepath)
    //        val dirs = Array("8", "9")
    val experiences = dirs.map(d => new Experience(filepath, outfilepath, d, 1, 100, ext = ""))
    //    println(experiences)
    experiences.foreach { exp =>
      // Delete old results
      //      cleanResults(exp)


      featuresGenerator(sc, exp)
    }

    //inserted here
   // val stopWords = sc.broadcast(loadStopWords("/stopwords.txt")).value
    //val labelToNumeric = createLabelMap("docs/inputData/")

    //val documents = sc.wholeTextFiles("docs/inputData/*")
     // .map(rawText => createLabeledDocument(rawText, labelToNumeric, stopWords))
    //val documents: RDD[Seq[String]] = sc.textFile("docs/inputData/*.*").map(line => line.split(" ").toSeq)
  //  val features_nlp = tfidfTransformer(documents)
   // features_nlp.foreach(vv => println(vv))
   // features_nlp.saveAsTextFile("docs/outputData/comp.graphics")

    /*val hashingTF = new HashingTF()
    val tf = hashingTF.transform(documents)


    tf.cache()
    val idf = new IDF(minDocFreq = 1).fit(tf)//: RDD[Vector]

    val tfidf = idf.transform(tf)//: RDD[Vector]

    //Deleting output files recursively if exists
    val dir = Path("docs/outputData")
    if (dir.exists) {
      dir.deleteRecursively()
      println("Deleting the old files")
    }
    println("New files writing")
    tfidf.saveAsTextFile("docs/outputData")
*/
    println("Successfully Done!")


    sc.stop()

  }
  def featuresGenerator(sc: SparkContext, exp: Experience): Unit = {
    val datas = parseForfeatures(sc, exp.dataPath).cache()
    // Cluster the data into two classes using KMeans
    // Load and parse the data
    /**
      * Calculate the no of clusters based on the no of data rows in a Data set/Class
      */
    //val K = clusterCount(datas.count(), exp.nbTotProto)
    println(exp.name + " : " + exp.nbTotProto + " = " )

    val stopWords = sc.broadcast(loadStopWords("/stopwords.txt")).value

    println(exp.dataPath+" ")
   // val labelToNumeric = createLabelMap("exp.dataPath")

    //for each file
    for (file <- new File(exp.dataPath+"/").listFiles) {

        println(file)
        //val document=sc.textFile(file+"").map(rawText => createLabeledDocument(rawText, labelToNumeric, stopWords))


    }

    val documents = sc.wholeTextFiles(exp.dataPath+"/*")
      .map(rawText => createLabeledDocument(rawText, labelToNumeric, stopWords))
    //val documents: RDD[Seq[String]] = sc.textFile("docs/inputData/*.*").map(line => line.split(" ").toSeq)
    val features_nlp = tfidfTransformer(documents)
    features_nlp.foreach(vv => println(vv))
   // features_nlp.saveAsTextFile("docs/outputData/comp.graphics")
    //features_nlp.saveAsTextFile(exp.outDir + "/" + exp.name + ".extractedfeatures" + exp.nbTotProto)
    features_nlp.saveAsTextFile(exp.outDir + "/" )


    //    val clusters = KMeans.train(datas, K, globalNbIter)
    //    clusters.save(sc, exp.dir + "/" + exp.name)
    //    println(clusters.clusterCenters.mkString(" "))
    //    val kMeansCenters = sc.parallelize(clusters.clusterCenters)
    //    kMeansCenters.map(v => v.toArray.mkString(" ")).saveAsTextFile(exp.outDir + "/" + exp.name + ".clustering.kmeans_centers_" + exp.nbTotProto)
    //    val preds = dataKM.map(p => p.toArray.mkString(" ") + "," + clusters.predict(p))
    //    preds.saveAsTextFile(exp.outDir + "/" + exp.name + ".clustering.kmeans_" + exp.nbTotProto)
  }
  def parseForfeatures(sc: SparkContext, filePath: String): RDD[Vector] = {
    val data = sc.textFile(filePath).filter(l => l.length > 1)

    data.map {
      line =>
        val parts = line.split(',')
        val feature = parts(parts.length - 1).trim
        val filepath = parts(0).split("/")
        val arrayDouble = feature.split(' ').map(_.toDouble)
        Vectors.dense(arrayDouble.dropRight(1))
    }
  }

}