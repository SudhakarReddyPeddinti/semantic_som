This code extract the TF-IDF features from the text documents

